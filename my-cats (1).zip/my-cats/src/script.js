document.addEventListener('DOMContentLoaded', function() {
  document.querySelector().innerHTML
})



function hello() {
  alert("Contacts will be available shortly")
}

function hi(){ 
  document.querySelector("h1").innerHTML="Getting Started";
  
}
let counter = 0
function count(){
  counter++;
  document.querySelector("#counter").innerHTML=counter;
  if (counter % 5 === 0){
    alert(`Counter at ${counter}`);
  }
}
